// eclaring the variables
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var backgroundImage

function preload(){
// loading sound and animation also images
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacelImage = loadImage("obstacle.png");
  backgroundImage = loadImage("jungle.jpg");
}

function setup() {
   createCanvas(500, 400);
// creating and modifying sprites
  var survivalTime=0;
  
  bg = createSprite(400,100);
  bg.addImage("w ",backgroundImage)
  
  //creating monkey
   monkey=createSprite(80,315,20,20);
   monkey.addAnimation("moving", monkey_running);
   monkey.addImage(bananaImage)
   monkey.scale=0.1
  
  //creating ground
  ground = createSprite(400,350,900,10);
  ground.velocityX=-0.1;
  ground.x=ground.width/2;
  ground.visible = false;
  console.log(ground.x)
  
  FoodGroup = new Group();
  
  obstaclesGroup = new Group();
  
  score = 0;
  }

function draw() {
  background(255);
  // function draw
    bg.velocityX = -3 
  
   if (bg.x < 0)
      bg.x = bg.width/4;
  
  
  if(ground.x<0) {
    ground.x=ground.width/2;
    
  }

  //add gravity
  monkey.velocityY = monkey.velocityY + 0.8
     
  if(keyDown("space") ) {
      monkey.velocityY = -12;
    }
  
  
   monkey.collide(ground);   
   spawnFood();
   spawnObstacles();

  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 300,50); 

  if(obstaclesGroup.isTouching(monkey)){
  
    text("you lost",200,200)
    monkey.velocityY=0
    backgroundImage.velocityY=0
    
   }
  
  if(FoodGroup.isTouching(monkey)){
    
     FoodGroup.destroyEach();
    score = score +2
     }
  
    switch(score){
      case 10: monkey.scale=0.12;
         break;
      case 20: monkey.scale=0.14;
        break;
      case 30: monkey.scale=0.16;
        break;
      case 40: monkey.scale=0.18;
        break;
        default:break;
        }

  
  textSize(20);

  survivalTime=Math.ceil(frameCount/frameRate()) 
  text("Survival Time: "+ survivalTime, 100,50);
  
}

function spawnFood() {
  // to spawn banana on different places
    if (frameCount % 80 === 0) {
    banana = createSprite(600,250,40,10);
    banana.y = random(120,200);    
    banana.velocityX = -5;
    
//assign lifetime to the variable
    banana.lifetime = 300;
    monkey.depth = banana.depth + 1;
    
      //add image of banana
     banana.addImage(bananaImage);
     banana.scale=0.1;
    
    //add each banana to the group
    FoodGroup.add(banana);
  }
}
//to spawn obstacles on different places
function spawnObstacles() {
  if(frameCount % 100 === 0) {
    obstacle = createSprite(800,320,10,40);
    obstacle.velocityX = -6;
    
    //add image to the obstacle 
    obstacle.addImage(obstacelImage);
    obstacle.scale=0.15;
    
    //lifetime to the obstacle     
    obstacle.lifetime = 300;
    
    //add each obstacle to the group
    obstaclesGroup.add(obstacle);
  }
}